<?php
mysql_connect('localhost', 'root', '');
mysql_select_db('js-global');
	$instituteid = $_POST['instituteid'];
	$sql = "select * from institution";
	$r = mysql_query($sql);
	while($s = mysql_fetch_row($r))
	{
		if($s[0] == $instituteid)
		{
			print '<option id="option" value = "'.$s[0].'" selected="Selected">'.$s[1].'</option>';
		}
		else
		{
			print '<option id="option" value = "'.$s[0].'">'.$s[1].'</option>';
		}
		
	}


?>