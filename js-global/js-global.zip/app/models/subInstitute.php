<?php
class subInstitute extends Eloquent{

	protected $fillable = array('name', 'institutionid'); 
	protected $table = 'sub_institution';

}
