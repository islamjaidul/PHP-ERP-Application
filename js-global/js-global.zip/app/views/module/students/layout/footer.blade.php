

<!-- jQuery -->

<!-- Place inside the <head> of your HTML -->

    {{HTML::script('js/jquery.js')}}
	
	@yield('footer')

    <!-- Bootstrap Core JavaScript -->
  {{HTML::script('js/bootstrap.min.js')}}

    <!-- Metis Menu Plugin JavaScript -->
    {{HTML::script('js/plugins/metisMenu/metisMenu.min.js')}}

    <!-- Morris Charts JavaScript -->
    {{HTML::script('js/plugins/morris/raphael.min.js')}}
    {{HTML::script('js/plugins/morris/morris.min.js')}}
	{{HTML::script('js/plugins/morris/morris-data.js')}}


    <!-- Custom Theme JavaScript -->
    {{HTML::script('js/sb-admin-2.js')}}

</body>

</html>
