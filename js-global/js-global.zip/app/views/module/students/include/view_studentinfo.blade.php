<div class="modal fade" id="confirm-view"> 
        <div class="modal-dialog">
            <div class="modal-content">
            
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Information</h4>
                </div>
            
                <div id="body" class="modal-body">
				
					
                   
                </div>
                
                <div class="modal-footer">
					                    
				
                </div>
            </div>
        </div>
    </div>
