
<div class="modal fade" id="confirm-delete"> 
        <div class="modal-dialog">
            <div class="modal-content">
            
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Confirm Delete</h4>
                </div>
            
                <div class="modal-body">
                    <p>You are about to delete one record, this procedure is irreversible.</p>
                    <p>Do you want to proceed?</p>
                    <p class="debug-url"></p>
                </div>
                
                <div class="modal-footer">
                   
					<form method="get" action="{{ URL::route('get_delete_coverletter') }}">
					@foreach($rows as $row)
					<input type="hidden" name="id" value="{{ $row -> id }}">
					<input type="hidden" name="attachment" value="{{ $row -> attachment1 }}">
					<input type="hidden" name="attachment1" value="{{ $row -> attachment2 }}">
					<input type="hidden" name="attachment2" value="{{ $row -> attachment3 }}">
					<input type="hidden" name="attachment3" value="{{ $row -> attachment4 }}">
					@endforeach
                    <input type="submit" id="delete" class="btn btn-danger danger" value="Delete">
					 <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					</form>
					
                </div>
            </div>
        </div>
    </div>